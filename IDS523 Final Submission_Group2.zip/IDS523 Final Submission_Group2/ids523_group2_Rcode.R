#*****************************************************************************************************
#**** IDS523 Spring 2022 Group 2 Final Project *******************************************************
#*#*********************Group 2 *********************************************************************
#*****************************************************************************************************

#*****************************************************************************************************
#************** Pull GitHub Repository Files *********************************************************
#*****************************************************************************************************
  library(devtools)
  devtools::install_github("ids523sp22/ids523group2")
  library(ids523group2)
  devtools::load_all()


  ap_ledger <- read.csv(
    system.file("extdata", "ap_ledger.csv", package = "ids523group2", mustWork = TRUE));
  collections_journal <- read.csv(
    system.file("extdata", "collections_journal.csv", package = "ids523group2", mustWork = TRUE));
  customer_credit_limits <- read.csv(
    system.file("extdata", "customer_credit_limits.csv", package = "ids523group2", mustWork = TRUE));
  daily_ar_balance <- read.csv(
    system.file("extdata", "daily_ar_balance.csv", package = "ids523group2", mustWork = TRUE));
  deposit_daily <- read.csv(
    system.file("extdata", "deposit_daily.csv", package = "ids523group2", mustWork = TRUE));
  disbursement_journal <- read.csv(
    system.file("extdata", "disbursement_journal.csv", package = "ids523group2", mustWork = TRUE));
  expenditures <- read.csv(
    system.file("extdata", "expenditures.csv", package = "ids523group2", mustWork = TRUE));
  fyear_begin_inventory_ledger <- read.csv(
    system.file("extdata", "fyear_begin_inventory_ledger.csv", package = "ids523group2", mustWork = TRUE));
  fyear_end_ar_ledger <- read.csv(
    system.file("extdata", "fyear_end_ar_ledger.csv", package = "ids523group2", mustWork = TRUE));
  perpetual_inventory_ledger <- read.csv(
    system.file("extdata", "perpetual_inventory_ledger.csv", package = "ids523group2", mustWork = TRUE));
  purchase_journal <- read.csv(
    system.file("extdata", "purchase_journal.csv", package = "ids523group2", mustWork = TRUE));
  real_world_cash_sales <- read.csv(
    system.file("extdata", "real_world_cash_sales.csv", package = "ids523group2", mustWork = TRUE));
  real_world_collections <- read.csv(
    system.file("extdata", "real_world_collections.csv", package = "ids523group2", mustWork = TRUE));
  real_world_credit_sales <- read.csv(
    system.file("extdata", "real_world_credit_sales.csv", package = "ids523group2", mustWork = TRUE));
  real_world_fyear_end_ar_ledger <- read.csv(
    system.file("extdata", "real_world_fyear_end_ar_ledger.csv", package = "ids523group2", mustWork = TRUE));
  real_world_ye_inventory <- read.csv(
    system.file("extdata", "real_world_ye_inventory.csv", package = "ids523group2", mustWork = TRUE));
  receiver_journal <- read.csv(
    system.file("extdata", "receiver_journal.csv", package = "ids523group2", mustWork = TRUE));
  sales_journal <- read.csv(
    system.file("extdata", "sales_journal.csv", package = "ids523group2", mustWork = TRUE));
  shipments_journal <- read.csv(
    system.file("extdata", "shipments_journal.csv", package = "ids523group2", mustWork = TRUE));
  RAM <- read.csv(
    system.file("extdata", "RAM.csv", package = "ids523group2", mustWork = TRUE));


  head(ap_ledger)
  head(collections_journal)
  head(customer_credit_limits)
  head(daily_ar_balance)
  head(deposit_daily)
  head(disbursement_journal)
  head(expenditures)
  head(fyear_begin_inventory_ledger)
  head(fyear_end_ar_ledger)
  head(perpetual_inventory_ledger)
  head(purchase_journal)
  head(real_world_cash_sales)
  head(real_world_collections)
  head(real_world_credit_sales)
  head(real_world_fyear_end_ar_ledger)
  head(real_world_ye_inventory)
  head(receiver_journal)
  head(sales_journal)
  head(shipments_journal)

  summary(ap_ledger)
  summary(collections_journal)
  summary(customer_credit_limits)
  summary(daily_ar_balance)
  summary(deposit_daily)
  summary(disbursement_journal)
  summary(expenditures)
  summary(fyear_begin_inventory_ledger)
  summary(fyear_end_ar_ledger)
  summary(perpetual_inventory_ledger)
  summary(purchase_journal)
  summary(real_world_cash_sales)
  summary(real_world_collections)
  summary(real_world_credit_sales)
  summary(real_world_fyear_end_ar_ledger)
  summary(real_world_ye_inventory)
  summary(receiver_journal)
  summary(sales_journal)
  summary(shipments_journal)

#*****************************************************************************************************
#*****************************************************************************************************

#*****************************************************************************************************
#******************* Question 1 **********************************************************************
#*****************************************************************************************************
  library(ggplot2)
  library(plotluck)
  library(viridis)
  library(hrbrthemes)
  library(sqldf)

  q1_Journal_counts <- data.frame(
    journal=c("ap_ledger",
              "collections_journal",
              "customer_credit_limits",
              "daily_ar_balance",
              "deposit_daily",
              "disbursement_journal",
              "expenditures",
              "fyear_begin_inventory_ledger",
              "fyear_end_ar_ledger",
              "perpetual_inventory_journal",
              "purchase_journal",
              "real_world_cash_sales",
              "real_world_collections",
              "real_world_credit_sales",
              "real_world_fyear_end_ar_ledger",
              "real_world_ye_inventory",
              "receiver_journal",
              "sales_journal",
              "shipments_journal"),
    record_count= c(nrow(ap_ledger),
                    nrow(collections_journal),
                    nrow(customer_credit_limits),
                    nrow(daily_ar_balance),
                    nrow(deposit_daily),
                    nrow(disbursement_journal),
                    nrow(expenditures),
                    nrow(fyear_begin_inventory_ledger),
                    nrow(fyear_end_ar_ledger),
                    nrow(perpetual_inventory_ledger),
                    nrow(purchase_journal),
                    nrow(real_world_cash_sales),
                    nrow(real_world_collections),
                    nrow(real_world_credit_sales),
                    nrow(real_world_fyear_end_ar_ledger),
                    nrow(real_world_ye_inventory),
                    nrow(receiver_journal),
                    nrow(sales_journal),
                    nrow(shipments_journal)),
    median_value = c(median(ap_ledger$extended_cost, na.rm = TRUE),
                     median(collections_journal$collection_amount, na.rm = TRUE),
                     median(customer_credit_limits$credit_limit, na.rm = TRUE),
                     median(daily_ar_balance$ar_balance, na.rm = TRUE),
                     median(deposit_daily$deposit_amount, na.rm = TRUE),
                     median(disbursement_journal$no_units_ordered * disbursement_journal$unit_cost, na.rm = TRUE),
                     median(expenditures$amount, na.rm = TRUE),
                     median(fyear_begin_inventory_ledger$stock_on_hand * fyear_begin_inventory_ledger$unit_cost, na.rm = TRUE),
                     median(fyear_end_ar_ledger$amount, na.rm = TRUE),
                     median(perpetual_inventory_ledger$stock_on_hand, na.rm = TRUE),
                     median(purchase_journal$po_count * purchase_journal$unit_cost, na.rm = TRUE),
                     median(real_world_cash_sales$collection_amount, na.rm = TRUE),
                     median(real_world_collections$sales_extended, na.rm = TRUE),
                     median(real_world_credit_sales$collection_amount, na.rm = TRUE),
                     median(real_world_fyear_end_ar_ledger$amount, na.rm = TRUE),
                     median(real_world_ye_inventory$ye_stock_on_hand * real_world_ye_inventory$unit_cost, na.rm = TRUE),
                     median(receiver_journal$received * receiver_journal$unit_cost, na.rm = TRUE),
                     median(sales_journal$sales_extended, na.rm = TRUE),
                     median(sqldf("SELECT a.sku, SUM(a.quantity) total_quantity FROM shipments_journal a GROUP BY a.sku")$total_quantity, na.rm = TRUE))
  );


  #Journal Record counts
  ggplot(q1_Journal_counts, aes( y=record_count, x=reorder(journal,-record_count), fill=journal)) +
    geom_bar(position="dodge", stat="identity")+
    scale_fill_viridis(discrete = T) +
    ggtitle("Journal Record Counts") +
    theme_ipsum() +
    xlab("")  +
    theme(axis.text.x=element_blank(),
          axis.ticks=element_blank(),
          axis.title.x=element_blank(),
          legend.title=element_blank(),
          axis.title.y=element_blank()) +
    geom_text(aes(label = record_count), vjust = -0.2, size=3)



  ###########################
  ## RAM Shiny Application ##
  ###########################
  library(shiny)

  # Define the User Interface (UI)
  ui <- fluidPage(
    titlePanel("Risk Assessment Matrix"),
    sidebarLayout(
      sidebarPanel(
        # Input: statistical confidence level of the audit tests
        sliderInput("confidence", "Confidence:",
                    min = .7, max = .999,
                    value = .95),
        # Input: cost of auditing per transaction sampled
        sliderInput("cost", "Audit $ / transaction:",
                    min = 0, max = 500,
                    value = 100),
        # Input: Text for providing a caption for the RAM
        textInput(inputId = "caption",
                  label = "Client:",
                  value = "Leyden, Inc.")
      ),
      # Main panel for displaying outputs
      mainPanel(
        # Output: slider values entered
        tableOutput("values"),
        # Output: Formatted text for caption
        h3(textOutput("caption", container = span)),
        # Output: total cost of the audit
        textOutput("view"),
        # Output: RAM summary with sample sizes (scope) and cost
        verbatimTextOutput("summary"),
        h6("Risk choices are: 1 = Low, 2=Medium, 3=High"),
        h6("Risk_intel = the risk level indicated by business intelligence scanning"),
        #h6("Risk_prior = the risk level indicated by audits in prior years"),
        h6("Account Amount and the Ave. Transaction size are in
$ without decimals or 000 dividers"),
        h6("Scope = estimated discovery sample size that will be needed in the
audit of this account"),
        h6("Audit cost = audit labor dollars per sampled transaction"),
        h6("Confidence = statistical confidence")
      )
    )
  )
  # Define Server-size calculations
  server <- function(input, output) {# auditors risk assessment matrix generated from prior years' workpapers, etc.
    ram <- read.csv(system.file("extdata", "RAM.csv", package = "ids523group2", mustWork = TRUE))
    sliderValues <- reactive({
      data.frame(Audit_Parameter = c("confidence","cost"),
                 Value = as.character(c(input$confidence,input$cost)),
                 stringsAsFactors = FALSE)})
    # Show the values in an HTML table ----
    output$values <- renderTable({ sliderValues()})
    output$caption <- renderText({input$caption})
    # Recompute scope and cost whenever input$confidence or input$cost change
    output$summary <- renderPrint({
      ram <- ram
      conf <- input$confidence
      cost <- input$cost
      #risk <- (10 - (as.numeric(ram[,2]) * as.numeric(ram[,3])) )/100
      risk <- (10 - as.numeric(ram[,2]))/100
      Scope <- ceiling( log(1-conf) / log( 1- risk))
      ram <- cbind(ram[,1:4], Scope)
      Min_cost <- Scope * cost
      ram <- cbind(ram[,1:5], Min_cost)
      ram})
    # Recompute minimum audit cost whenever input$confidence or input$cost change
    output$view <- renderText({
      ram <- ram
      conf <- input$confidence
      cost <- input$cost
      #risk <- (10 - (as.numeric(ram[,2]) * as.numeric(ram[,3])) )/100
      risk <- (10 - as.numeric(ram[,2]) )/100
      Scope <- ceiling( log(1-conf) / log( 1- risk))
      ram <- cbind(ram[,1:4], Scope)
      Min_cost <- Scope * cost
      minimum_audit_cost <- sum(Min_cost)
      c("Minimum estimated audit cost = ",minimum_audit_cost)})
  }


  shinyApp(ui, server)


  plotluck(ap_ledger, .~1)
  plotluck(collections_journal, .~1)
  plotluck(customer_credit_limits, .~1)
  plotluck(daily_ar_balance, .~1)
  plotluck(deposit_daily, .~1)
  plotluck(disbursement_journal, .~1)
  plotluck(expenditures, .~1)
  plotluck(fyear_begin_inventory_ledger, .~1)
  plotluck(fyear_end_ar_ledger, .~1)
  plotluck(perpetual_inventory_ledger, .~1)
  plotluck(purchase_journal, .~1)
  plotluck(real_world_cash_sales, .~1)
  plotluck(real_world_collections, .~1)
  plotluck(real_world_credit_sales, .~1)
  plotluck(real_world_fyear_end_ar_ledger, .~1)
  plotluck(real_world_ye_inventory, .~1)
  plotluck(receiver_journal, .~1)
  plotluck(sales_journal, .~1)
  plotluck(shipments_journal, .~1)

#*****************************************************************************************************
#******************* Question 2 **********************************************************************
#*****************************************************************************************************

  library(tidyverse)
  
  library(stringr)
  
  library(dplyr)
  
  library(readr)
  
  
  #INVOICE NO
  
  dup_sales <- sales_journal[duplicated(sales_journal$invoice_no), ]
  
  n <- nrow(dup_sales)
  
  cat("\n # of duplicate invoice = ", n)
  
  cat("\n % of duplicate invoice number =",n/99678,"%") 
  
  
  
 # SHIPMENT NO
  
  dup_shipment <- shipments_journal[duplicated(shipments_journal$shipper_no), ]
  
  n <- nrow(dup_shipment)
  
  cat("\n # of duplicate shipment no = ", n)
  
  cat("\n % of duplicate shipment =",((n/100000)*100),"%")
  
  
  
  #COLLECTION NO
  
  dup_collection <- collections_journal[duplicated(collections_journal$collection_no), ]
  
  n <- nrow(dup_collection)
  
  cat("\n # of duplicate collection no = ", n)
  
  cat("\n % of duplicate collection no =",((n/79924)*100),"%")
  
  
  
 # OMMISSIONS
  
  #INVOICE
  
  invoiceno <- as.numeric(substring(sales_journal$invoice_no, 2))
  
  invoiceno_min <- as.numeric(min(invoiceno))
  
  invoiceno_max <- as.numeric(max(invoiceno))
  
  omit<-as.data.frame(setdiff(invoice_min:invoice_max,invoiceno))
  
  n<-nrow(omit)
  
  cat("\n number of omitted invoice numbers=",n)
  
  cat("\n % of omitted invoice numbers=",((n/99678)*100), "%")
  
  
  
  #SHIPMENT
  
  shipno <- as.numeric(substring(shipments_journal$shipper_no, 2))
  
  shipno_min <- as.numeric(min(shipno))
  
  shipno_max <- as.numeric(max(shipno))
  
  omit<-as.data.frame(setdiff(shipno_min:shipno_max,shipno))
  
  n<-nrow(omit)
  
  cat("\n number of omitted shipno numbers=",n)
  
  cat("\n % of omitted shipno numbers=",((n/100000)*100), "%")
  
  
  
  #COLLECTION
  
  collno <- as.numeric(substring(collections_journal$collection_no, 2))
  
  collno_min <- as.numeric(min(collno))
  
  collno_max <- as.numeric(max(collno))
  
  omit<-as.data.frame(setdiff(collno_min:collno_max,collno))
  
  n<-nrow(omit)
  
  cat("\n number of omitted collno numbers=",n)
  
  cat("\n % of omitted collno numbers=",((n/79924)*100),"%")
  
  
  
  library(sqldf)
  
  cust_neg_bal <- sqldf
  
  daily_ar_balance = read.csv("C:\Users\sparky12\Downloads\auditanalytics_final_files (1)\auditanalytics_final_files\daily_ar_balance.csv")
  
  cat("\n # Percent of customers with Credit Balances = ",(nrow(cust_neg_bal)*100/nrow(daily_ar_balance)),"%")== 0
  
  
  
  library(tidyverse)
  
 # CUSTOMERS WITH CREDIT BALANCES
  
  library(lubridate)
  
  library(kableExtra)
  
  # set the fiscal year end date to match the dataset
  
  fyear_end <- paste0(format(Sys.Date(), "%Y"), "-12-31")
  
  ## create the unpaid_ar
  
  sales_journal[is.na(sales_journal)] <- 0
  
  credit_sales_journal <-
    
    sales_journal %>%
    
    filter(cash_not_ar == 0)
  
  unpaid_ar <-
    
    credit_sales_journal[
      
      credit_sales_journal$collection_date >= fyear_end &
        
        credit_sales_journal$shipper_date <= fyear_end,]
  
  foot <-
    
    unpaid_ar %>%
    
    select(sales_extended) %>%
    
    sum()
  
  cat("\n\n A/R balance = ",foot)


#*****************************************************************************************************
#******************* Question 3 **********************************************************************
#*****************************************************************************************************

  # discovery sampling

  confidence <- seq(.99,.7,-.01)
  n <- (log(1-confidence))/log(1-.05)
  plot(confidence,n, type="l")

  confidence <- .95
  n <- (log(1-confidence))/log(1-.05)
  cat("\n Discovery sample size = ", ceiling(n))


# discovery sampling - error


  library(tidyverse)
  library(compareDF)
  library(arsenal)
  library(compare)
  library(auditanalytics)
  sample_size = 59 # set the sample size based on the discovery sample algorithm
  sales_temp <- split(sales_journal,sales_journal$cash_not_ar)
  sales_journal_cr <- sales_temp$"0" ## select only credit sales
  discovery_sample_sales <-
    sales_journal[runif(sample_size,1,nrow(sales_journal)),] %>%
    select(invoice_no,
           sales_unit_price,
           sales_count)
  real_world_all_sales <- rbind(real_world_cash_sales,real_world_credit_sales)
  audited_sample <-
    left_join(discovery_sample_sales,
              real_world_all_sales,
              by="invoice_no") %>%
    select(invoice_no,
           sales_unit_price.x,
           sales_count.x,
           sales_unit_price.y,
           sales_count.y)
  exceptions <-
    audited_sample %>%
    filter(sales_unit_price.x != sales_unit_price.y |
             sales_count.x != sales_count.y
    )
  error_rate_sales <- nrow(exceptions) / nrow(audited_sample)
  cat("\n \n \n Discovery: error rate in sales:", error_rate_sales)

  error_sales_amt <-
    100 * sum(exceptions$sales_count.y * exceptions$sales_count.y ) /
    sum(audited_sample$sales_unit_price.x * audited_sample$sales_count.x)
  cat("\n \n Discovery: amount for sales sample is overstated (i.e., is in error):",
      prettyNum(error_sales_amt, big.mark=","),
      " %")


#attribute sampling
  
  
  credit_sales_journal <-sales_journal %>%
    filter(cash_not_ar == 0)
  
  library(readr)
  library(pwr)
  library(tidyverse)
  size <- as.numeric(nrow(credit_sales_journal))
  ## data set size
  Delta <- .05*size
  ## detect 5% occurrence error
  sigma <- .3*size
  ## variability (guess ~1/3 rd)
  effect <- Delta/sigma
  sample <- pwr.t.test(
    d=effect,
    sig.level = 0.05,
    power = .8,
    type="one.sample",
    alternative="greater") ## look for overstatement of earnings
  cat("\n \n Attribute sample size for occurrence of error = ", ceiling(sample$n))
  
  size <-
    as.numeric(
      sum(
        credit_sales_journal$sales_unit_price*
          credit_sales_journal$sales_count))
  ## data set size
  mu <-
    mean(
      credit_sales_journal$sales_unit_price*
        credit_sales_journal$sales_count)
  ## average value of transaction
  Delta <- .05*mu
  ## detect 5% amount intolerable error
  sigma <-
    sd(credit_sales_journal$sales_unit_price*
         credit_sales_journal$sales_count)
  ## variability
  effect <- Delta/sigma
  sample <- pwr.t.test(
    d=effect,
    sig.level = 0.05,
    power = .8,
    type="one.sample",
    alternative="greater") ## look for sales value too large
  cat("\n Attribute sample size for amount of error = ", ceiling(sample$n))
  
  

  
  # acceptance sampling


  library(readr)
  library(pwr)


  ## data set size
  size <- as.numeric(nrow(sales_journal))
  ## average value of transaction
  mu <- mean(sales_journal$sales_unit_price*sales_journal$sales_count)
  Delta <- .05*mu # detect 5% (material) error in sample
  sigma <- sd(sales_journal$sales_unit_price*sales_journal$sales_count) # variability
  effect <- Delta/sigma
  sample <- pwr.t.test(
    d=effect,
    sig.level = 0.05,
    power = .8,
    type="one.sample",
    alternative="greater") ## look for AR value too large
  cat("\n Acceptance sample size = ", ceiling(sample$n))


  # error rate


  library(broom)
  library(readr)
  library(tidyverse)
  library(compare)
  library(auditanalytics)

  acceptance_sample_ar <- sales_journal[runif(1950,1,
                                                    nrow(sales_journal)),]

  audited_sample <-
    left_join(acceptance_sample_ar,
              real_world_all_sales,
              by="invoice_no") %>%
    select(invoice_no,
           sales_unit_price.x,
           sales_count.x,
           sales_unit_price.y,
           sales_count.y,
           collection_amount.x,
           collection_amount.y)
  exceptions <-
    audited_sample %>%
    
    filter(collection_amount.x != collection_amount.y |
             sales_unit_price.x != sales_unit_price.y |
             sales_count.x != sales_count.y)
  error_rate_sales <- nrow(exceptions) / nrow(audited_sample)
  
  cat("\n \n \n error rate in sales:", error_rate_sales)

  error_sales_amt <-
    100 * sum(exceptions$sales_count.y * exceptions$sales_count.y ) /
    sum(audited_sample$sales_unit_price.x * audited_sample$sales_count.x)
  cat("\n \n amount for sales sample is overstated (i.e., is in error):",
      prettyNum(error_sales_amt, big.mark=","),
      " %")


  
#*****************************************************************************************************
#******************* Question 4 **********************************************************************
#*****************************************************************************************************

  library(tidyverse)
  library(lubridate)
  library(kableExtra)
  library(dplyr)
  
  
  ar_outstanding <- sales_journal
  ar_outstanding <- ar_outstanding[!( ar_outstanding$invoice_no %in% collections_journal$invoice_no),]
  
  fyear_start <- paste0(format(Sys.Date(), "2021"), "-01-01")
  fyear_end <- paste0(format(Sys.Date(), "2021"), "-12-31")
  
  ar_outstanding_fye <- ar_outstanding %>% filter(invoice_date >= fyear_start)
  ar_outstanding_fye <- ar_outstanding_fye %>% filter(invoice_date <= fyear_end)
  
  ## create age breaks at &lt;30 days; 30 - 60 days; &gt;60 days
 
  age_ar <-
    ar_outstanding_fye %>%
    filter(cash_not_ar == 0) %>%
    filter(collection_date > fyear_end) %>%
    mutate(i_date <- yday(ymd(as_date(invoice_date))),
           ye_date <- yday(ymd(as_date(fyear_end))),
           age =ye_date - i_date,
           age_lt_30 = ifelse(age<30, sales_extended, 0),
           age_30_60 = ifelse(age<=60 & age>=30,sales_extended,0),
           age_gt_60 = ifelse(age>60,sales_extended,0) ## redundant but easier to read
    ) %>%
    select(customer_no, invoice_no, age, sales_extended,age_lt_30, age_30_60, age_gt_60)
  
  ## aging by customer
  customer_age_ar <-
    age_ar %>%
    group_by(customer_no) %>%
    summarize(total = sum(sales_extended),
              lt_30 = sum(age_lt_30),
              between_30_60 = sum(age_30_60),
              gt_60 = sum(age_gt_60)
    ) %>%
    select(customer_no, total,lt_30, between_30_60, gt_60)
  
  ar_total_amount <- sum(customer_age_ar$total)
  
  ar_age_30_doll<-sum(customer_age_ar$lt_30)
  ar_age_30_60_doll<-sum(customer_age_ar$between_30_60)
  ar_age_gt_60_doll<-sum(customer_age_ar$gt_60)
  
  ar_age_30_percent<-ar_age_30_doll/ar_total_amount * 100
  ar_age_30_60_percent<-ar_age_30_60_doll/ar_total_amount * 100
  ar_age_gt_60_percent<-ar_age_gt_60_doll/ar_total_amount * 100
  
  cat("\n\n Outstanding A/R balance of invoices under 30 days old: ", ar_age_30_doll,"\n")
  cat("\n\n Outstanding A/R balance of invoice between 30 to 60 days old: ",ar_age_30_60_doll,"\n")
  cat("\n\n Outstanding A/R balance of invoices over 60 days old: ",ar_age_gt_60_doll,"\n")
  
  cat("\n\n Percentage A/R balance of invoices under 30 days old: ",ar_age_30_percent,"%\n")
  cat("\n\n Percentage A/R balance of invoice between 30 to 60 days old: ",ar_age_30_60_percent,"%\n")
  cat("\n\n Percentage A/R balance of invoices over 60 days old: ",ar_age_gt_60_percent,"%\n")
  
  
  
#*****************************************************************************************************
#******************* Question 5 **********************************************************************
#*****************************************************************************************************
  
  setwd("~/Documents/IDS  523 Final Project")
  
  customer_credit_limits <- read.csv("./auditanalytics_final_files/customer_credit_limits.csv")
  receiver_journal <- read.csv("./auditanalytics_final_files/receiver_journal.csv")
  sales_journal <- read.csv("./auditanalytics_final_files/sales_journal.csv")
  collections_journal <- read.csv("./auditanalytics_final_files/collections_journal.csv")
  fyear_end_ar_ledger <- read.csv("./auditanalytics_final_files/fyear_end_ar_ledger.csv")
  
  library(tidyverse) 
  library(lubridate) 
  library(knitr)
  library(kableExtra)
  
  fyear_end <- ('2021-12-31')
  
  sales_journal[is.na(sales_journal)] <- 0
  
  credit_sales_journal <- sales_journal %>% 
    filter(cash_not_ar == 0)
  
  unpaid_ar <- credit_sales_journal
  
  foot <-
    unpaid_ar %>% 
    select(sales_extended) %>% 
    sum()
  
  cat("\n\n A/R balance = ",foot)
  
  unpaid_ar_by_cust <-
    unpaid_ar %>%
    select(customer_no, invoice_date, invoice_no, sales_extended) %>% 
    group_by(customer_no) %>%
    select(sales_extended) %>% 
    summarise(customer_ye_balance=sum(sales_extended))
  
  -------------------------------------------------------------------------------
    
    collections_journal[is.na(collections_journal)] <- 0
  
  credit_sales_collections_journal <- collections_journal %>% 
    filter(cash_not_ar == 0)
  
  paid_ar_collections <-
    credit_sales_collections_journal[
      credit_sales_collections_journal$collection_date <= fyear_end,]
  
  foot <-
    paid_ar_collections %>% 
    select(collection_amount) %>% 
    sum()
  
  cat("\n\n Amount collected by year end 2021 = ",foot)
  
  paid_ar_by_cust <-
    paid_ar_collections %>%
    select(customer_no, invoice_date, invoice_no, sales_extended) %>% 
    group_by(customer_no) %>%
    select(sales_extended) %>% 
    summarise(customer_paid_ye_balance=sum(sales_extended))
  
  ar_by_cust_summary <- merge(unpaid_ar_by_cust, paid_ar_by_cust, by="customer_no")
  
  ar_by_cust_summary <- ar_by_cust_summary %>%
    rowwise() %>%
    mutate(Outstanding_ar = (customer_ye_balance - customer_paid_ye_balance))
  
  ar_by_cust_summary <- merge(ar_by_cust_summary, customer_credit_limits, by="customer_no")
  ar_by_cust_summary <- subset(ar_by_cust_summary, select= -c(X))
  ar_by_cust_summary <- ar_by_cust_summary %>%
    relocate(credit_limit, .after = customer_no)
  
  --------------------------------------------------------------------------------
    
    fyear_end_ar_ledger[is.na(fyear_end_ar_ledger)] <- 0
  
  foot <-
    fyear_end_ar_ledger %>% 
    select(amount) %>% 
    sum()
  
  cat("\n\n fyear A/R balance = ",foot)
  
  fyear_end_ar_ledger <-
    fyear_end_ar_ledger %>%
    select(customer_no, shipper_date, invoice_no, amount) %>% 
    group_by(customer_no) %>%
    select(amount) %>% 
    summarise(fyear_customer_ye_balance=sum(amount))
  
  ar_by_cust_summary <- merge(ar_by_cust_summary, fyear_end_ar_ledger, by="customer_no")
  

#*****************************************************************************************************
#******************* Question 6 **********************************************************************
#*****************************************************************************************************

  sales_journal <- read.csv("./auditanalytics_final_files/sales_journal.csv")
  
  sales_journal[is.na(sales_journal)] <- 0
  
  sales_journal_cutoff <-
    sales_journal[
      sales_journal$shipper_date <= fyear_end,]
  
  sales_journal_next_year <-
    sales_journal[
      sales_journal$shipper_date > fyear_end,]

#*****************************************************************************************************
#******************* Question 7 **********************************************************************
#*****************************************************************************************************

  
  library(readr)
  library(pwr)
  library(tidyverse)
  
  #pull in datasets
  sales_journal <-
    read.csv((system.file("extdata", "sales_journal.csv", package =
                            "ids523group2", mustWork = TRUE)), na.strings="0", stringsAsFactors=FALSE)
  sales_journal[is.na(sales_journal)] <- 0
  
  credit_sales_journal <-sales_journal %>%
    filter(cash_not_ar == 0)
  
  Client_ar_ledger <- read_csv(system.file("extdata", "fyear_end_ar_ledger.csv", package =
                                             "ids523group2", mustWork = TRUE),
                               col_types = cols(...1 = col_skip()));
  
  
  real_world_ar <-
    read_csv(system.file("extdata", "real_world_fyear_end_ar_ledger.csv", package =
                           "ids523group2", mustWork = TRUE),
             col_types = cols(...1 = col_skip()));
  
  ## data set size
  size <- as.numeric(nrow(credit_sales_journal))
  
  ## detect 5% occurrence error
  Delta <- .05*size
  
  ## variability (guess ~1/3 rd)
  sigma <- .3*size
  
  effect <- Delta/sigma
  
  ## look for overstatement of earnings  
  sample <- pwr.t.test(
    d=effect,
    sig.level = 0.05,
    power = .8,
    type="one.sample",
    alternative="greater")
  
  cat("\n \n Attribute sample size for occurrence of error = ", ceiling(sample$n))
  
  ## data set size
  size <-
    as.numeric(
      sum(
        credit_sales_journal$sales_unit_price*
          credit_sales_journal$sales_count))
  
  ## average value of transaction
  mu <-
    mean(
      credit_sales_journal$sales_unit_price*
        credit_sales_journal$sales_count)
  
  ## detect 5% amount intolerable error
  Delta <- .05*mu
  
  ## variability
  sigma <-
    sd(credit_sales_journal$sales_unit_price*
         credit_sales_journal$sales_count)
  
  effect <- Delta/sigma
  
  ## look for sales value too large
  sample <- pwr.t.test(
    d=effect,
    sig.level = 0.05,
    power = .8,
    type="one.sample",
    alternative="greater")
  
  cat("\n Attribute sample size for amount of error = ", ceiling(sample$n))
  
  ## data set size
  size <- as.numeric(nrow(Client_ar_ledger))
  
  ## average value of transaction
  mu <- mean(Client_ar_ledger$amount)
  
  Delta <- .1*mu # detect 10% (material) error in sample
  
  sigma <- sd(Client_ar_ledger$amount) # variability
  
  effect <- Delta/sigma
  
  sample <- pwr.t.test(
    d=effect,
    sig.level = 0.05,
    power = .8,
    type="one.sample",
    alternative="greater") ## look for AR value too large
  
  cat("\n Acceptance sample size = ", ceiling(sample$n))
  
  nrow(Client_ar_ledger)
  
  class(Client_ar_ledger$...1)
  spec(Client_ar_ledger)
  
  acceptance_sample_ar <- Client_ar_ledger[as.integer(runif(sample$n,min=1,max=nrow(Client_ar_ledger))),]
  
  audited_sample <-
    inner_join(
      acceptance_sample_ar,
      real_world_ar,
      by="invoice_no") %>%
    select(
      invoice_no,
      customer_no.x,
      amount.x,
      confirm_exception,
      confirm_response)
  
  exceptions <- audited_sample[audited_sample$confirm_exception == 1,]
  
  occ_error_rate_ar <- nrow(exceptions) / nrow(acceptance_sample_ar)
  
  amt_error_rate_ar <- sum(exceptions$amount.x) / sum(acceptance_sample_ar$amount)
  
  sum(acceptance_sample_ar$amount)
  sum(exceptions$amount.x)
  sum(fyear_end_ar_ledger$amount)
  sum(real_world_ar$amount)
  
  cat("\n\n Occurrence error in Accounts Receivable on the Trial Balance ", occ_error_rate_ar)
  cat("\n\n Amount error in Accounts Receivable on the Trial Balance ", amt_error_rate_ar)
  
  


#*****************************************************************************************************
#******************* Question 8 **********************************************************************
#*****************************************************************************************************

  #import the files
  
  library(readr)
  purchase_journal <- read_csv("auditanalytics_final_files/purchase_journal.csv", 
                               col_types = cols(...1 = col_skip()))
  View(purchase_journal)
  
  receiver_journal <- read_csv("auditanalytics_final_files/receiver_journal.csv", 
                               col_types = cols(...1 = col_skip()))
  View(receiver_journal)
  
  
  #Calculate the percent of duplicates in Receiver Numbers:
  dup_receive <- receiver_journal[duplicated(receiver_journal$receiver_no), ]
  n <- nrow(dup_receive)
  cat("\n Number of duplicate receiver records = ", n)
  cat("\n Percentage of duplicate receiver records =",((n/1969)*100),"%")
  
  #Calculate the percent of ommissions in Receiver Numbers:  
  receiver <- as.numeric(substring(receiver_journal$receiver_no, 4))
  receiver_min <- as.numeric(min(receiver))
  receiver_max <- as.numeric(max(receiver))
  omit <- as.data.frame(setdiff(receiver_min:receiver_max, receiver))
  n <- nrow(omit)
  cat("\n Number of omitted receiver records = ", n)
  cat("\n Percentage of omitted receiver records=",((n/1969)*100),"%")
  
  
  #Calculate the percent of duplicates in Purchase Order Numbers:
  dup_purchase <- purchase_journal[duplicated(purchase_journal$po_no), ]
  n <- nrow(dup_purchase)
  cat("\n Number of duplicate purchases = ", n)
  cat("\n Percentage of duplicate Purchase =",((n/1963)*100),"%")
  
  #Calculate the percent of ommissions in Purchase Order Numbers:  
  po <- as.numeric(substring(purchase_journal$po_no, 2))
  po_min <- as.numeric(min(po))
  po_max <- as.numeric(max(po))
  omit <- as.data.frame(setdiff(po_min:po_max, po))
  n <- nrow(omit)
  cat("\n Number of omitted purchase records = ", n)
  cat("\n Percentage of omitted purchase records=",((n/1963)*100),"%")
  

#*****************************************************************************************************
#******************* Question 9 **********************************************************************
#*****************************************************************************************************

  library(tidyverse)
  slow_moving_skus <-
    perpetual_inventory_ledger %>%
    group_by(sku) %>%
    inner_join(sales_journal, by="sku") %>%
    slice(n()) %>%
    mutate(annual_sales = sales_unit_price * sales_count) %>%
    select(sku, annual_sales, stock_on_hand) %>%
    filter(annual_sales/stock_on_hand < 5) %>%
    as.data.frame()


#*****************************************************************************************************
#******************* Question 10 **********************************************************************
#*****************************************************************************************************

 library(tidyverse)
 real_world_ye_inventory[is.na(real_world_ye_inventory)] <- 0
 inventory_costs <- perpetual_inventory_ledger %>%
   group_by(sku) %>%
   slice(n()) %>% ## the final slice, by SKU, will be what is in-stock at year end
   inner_join(fyear_begin_inventory_ledger, by="sku") %>%
   select(sku,
          stock_on_hand.x,
          unit_cost,
          sales_unit_price,
          ) %>%
   mutate(cost = stock_on_hand.x * unit_cost,
     net_realisable = (stock_on_hand.x * sales_unit_price) - (0.1*cost)) %>%
   select(sku, stock_on_hand.x, unit_cost, sales_unit_price, cost, net_realisable) %>%
   as.data.frame() %>%
   filter(net_realisable < 1.1*cost)

 

#*****************************************************************************************************
#******************* Question 11 **********************************************************************
#*****************************************************************************************************

 library(readr)
 library(pwr)
 library(tidyverse)
 
 inventory_ledger <- read_csv(system.file("extdata", "fyear_begin_inventory_ledger.csv", package =
                                            "ids523group2", mustWork = TRUE),
                              col_types = cols(...1 = col_skip()));
 
 
 real_world_inventory <-
   read_csv(system.file("extdata", "real_world_ye_inventory.csv", package =
                          "ids523group2", mustWork = TRUE),
            col_types = cols(...1 = col_skip()));
 
 ## data set size
 size <- as.numeric(nrow(inventory_ledger))
 
 ## average value of transaction
 mu <- mean(inventory_ledger$stock_on_hand)
 
 Delta <- .1*mu # detect 10% (material) error in sample
 
 sigma <- sd(inventory_ledger$stock_on_hand) # variability
 
 effect <- Delta/sigma
 
 sample <- pwr.t.test(
   d=effect,
   sig.level = 0.05,
   power = .8,
   type="one.sample",
   alternative="greater") ## look for AR value too large
 
 cat("\n Acceptance sample size = ", ceiling(sample$n))
 
 nrow(inventory_ledger)
 
 class(inventory_ledger$...1)
 spec(inventory_ledger)
 
 acceptance_sample_inv <- inventory_ledger[as.integer(runif(sample$n,min=1,max=nrow(inventory_ledger))),]
 
 audited_sample_inv <-
   inner_join(
     acceptance_sample_inv,
     real_world_inventory,
     by="sku") %>%
   select(
     sku,
     unit_cost.x,
     stock_on_hand,
     ye_stock_on_hand,
     count_exception,
     exception)
 
 exceptions_inv <- audited_sample_inv[audited_sample_inv$count_exception == 1,]
 
 occ_error_rate_inv <- nrow(exceptions_inv) / nrow(acceptance_sample_inv)
 
 amt_error_rate_inv <- sum(exceptions_inv$stock_on_hand) / sum(acceptance_sample_inv$stock_on_hand)
 
 total_dollars_acceptance_sample_inv <- sum(acceptance_sample_inv$unit_cost * acceptance_sample_inv$stock_on_hand)
 total_dollars_exceptions_inv <- sum(exceptions_inv$unit_cost.x * exceptions_inv$stock_on_hand)
 total_dollars_inventory_ledger <- sum(inventory_ledger$unit_cost * inventory_ledger$stock_on_hand)
 total_dollars_real_world_inventory <- sum(real_world_inventory$unit_cost * real_world_inventory$ye_stock_on_hand, na.rm = TRUE)
 
 cat("\n\n Occurrence error in Inventory on the Trial Balance ", occ_error_rate_inv)
 cat("\n\n Amount error in Inventory on the Trial Balance ", amt_error_rate_inv)
 cat("\n\n Total dollar amount Inventory Ledger ", total_dollars_inventory_ledger)
 cat("\n\n Total dollar amount Real World Inventory ", total_dollars_real_world_inventory)
 cat("\n\n Difference Inventory Ledger to Real World Balance ", total_dollars_inventory_ledger - total_dollars_real_world_inventory)
 